package studio.spark.duels.match;

import studio.spark.duels.arena.Arena;
import studio.spark.duels.kit.Kit;
import studio.spark.duels.model.Mode;

import java.util.UUID;

public class Match {

    public enum State { PREPARING, LIVE, ENDED }

    private final UUID player1, player2;
    private final Mode mode;
    private final Kit kit;
    private final Arena arena;
    private final boolean ranked;
    private State state = State.PREPARING;
    private final long startTime = System.currentTimeMillis();

    public Match(UUID player1, UUID player2, Mode mode, Kit kit, Arena arena, boolean ranked) {
        this.player1 = player1;
        this.player2 = player2;
        this.mode = mode;
        this.kit = kit;
        this.arena = arena;
        this.ranked = ranked;
    }

    public boolean ranked() { return ranked; }

    public UUID player1() { return player1; }
    public UUID player2() { return player2; }
    public Mode mode() { return mode; }
    public Kit kit() { return kit; }
    public Arena arena() { return arena; }
    public State state() { return state; }
    public void state(State s) { this.state = s; }

    public UUID opponentOf(UUID id) { return id.equals(player1) ? player2 : player1; }
    public boolean has(UUID id) { return id.equals(player1) || id.equals(player2); }
    public long elapsedSeconds() { return (System.currentTimeMillis() - startTime) / 1000L; }
}
