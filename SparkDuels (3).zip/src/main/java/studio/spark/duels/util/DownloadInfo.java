package studio.spark.duels.util;

import java.util.logging.Logger;

/**
 * BuiltByBit leak-tracer. On download, BuiltByBit string-replaces the
 * placeholders below with the buyer's info. We ONLY log them on startup so a
 * leaked copy can be traced back to the buyer (BuiltByBit staff can then ban
 * them). There is intentionally NO lockout / disable logic here — this can
 * never brick a legitimate buyer's server.
 *
 * IMPORTANT:
 *  - Keep each placeholder as its own plain String literal. Do NOT concatenate
 *    them with other text or make them compile-time-folded constants, or
 *    BuiltByBit may not be able to inject them.
 *  - If you obfuscate the jar, EXCLUDE these placeholder identifiers from
 *    obfuscation so BuiltByBit can still find and replace them.
 *  - Enable/verify these on the BuiltByBit "Placeholders" page, then download
 *    your own copy and confirm they were replaced.
 */
public final class DownloadInfo {

    private DownloadInfo() {}

    // ---- BuiltByBit injects these per download ----
    private static String user()     { return "%%__USER__%%"; }
    private static String username() { return "%%__USERNAME__%%"; }
    private static String resource() { return "%%__RESOURCE__%%"; }
    private static String nonce()    { return "%%__NONCE__%%"; }
    private static String version()  { return "%%__VERSION__%%"; }

    /** True only if BuiltByBit actually replaced the placeholders on download. */
    public static boolean injected() {
        return !user().contains("%%");
    }

    public static String buyerId()  { return injected() ? user() : "unknown"; }
    public static String buyerName(){ return injected() ? username() : "unknown"; }

    /** Logs the buyer fingerprint on startup. Tracing only — never blocks. */
    public static void log(Logger log) {
        if (injected()) {
            log.info("[License] Licensed copy — buyer #" + user() + " (" + username() + ")"
                    + ", resource " + resource() + ", version " + version() + ", nonce " + nonce());
        } else {
            log.info("[License] No BuiltByBit download info present (dev build or direct copy).");
        }
    }
}
