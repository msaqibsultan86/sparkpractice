package studio.spark.duels.util;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Shared helpers for clean, bordered, centered menus. */
public final class Gui {

    private Gui() {}

    public static ItemStack pane(Material mat) {
        ItemStack p = new ItemStack(mat);
        ItemMeta m = p.getItemMeta();
        if (m != null) {
            m.displayName(Component.text(" "));
            p.setItemMeta(m);
        }
        return p;
    }

    /** Fill the outer border of the inventory. */
    public static void border(Inventory inv, ItemStack pane) {
        int size = inv.getSize();
        int rows = size / 9;
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, pane);
            inv.setItem(size - 9 + i, pane);
        }
        for (int r = 1; r < rows - 1; r++) {
            inv.setItem(r * 9, pane);
            inv.setItem(r * 9 + 8, pane);
        }
    }

    /** Accent the four corners. */
    public static void corners(Inventory inv, ItemStack pane) {
        int size = inv.getSize();
        inv.setItem(0, pane);
        inv.setItem(8, pane);
        inv.setItem(size - 9, pane);
        inv.setItem(size - 1, pane);
    }

    /** Fill every still-empty slot. */
    public static void fillEmpty(Inventory inv, ItemStack pane) {
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, pane);
        }
    }

    /** Centered content slots (inside the border) for {@code count} items. */
    public static int[] centered(int count, int size) {
        int rows = size / 9;
        int innerRows = Math.max(1, rows - 2);
        int perRow = 7;
        int rowsNeeded = Math.min(innerRows, Math.max(1, (int) Math.ceil(count / (double) perRow)));
        int startRow = 1 + Math.max(0, (innerRows - rowsNeeded) / 2);
        List<Integer> slots = new ArrayList<>();
        int remaining = count;
        for (int r = 0; r < rowsNeeded && remaining > 0; r++) {
            int inThis = Math.min(perRow, remaining);
            int startCol = 1 + (perRow - inThis) / 2;
            for (int c = 0; c < inThis; c++) slots.add((startRow + r) * 9 + startCol + c);
            remaining -= inThis;
        }
        return slots.stream().mapToInt(Integer::intValue).toArray();
    }

    /** Pick an inventory size (multiple of 9) that fits a bordered grid of {@code count}. */
    public static int sizeFor(int count) {
        if (count <= 7) return 27;
        if (count <= 14) return 45;
        return 54;
    }
}
