package studio.spark.duels.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.model.Mode;
import studio.spark.duels.util.Gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Mode picker for the per-player kit editor. */
public class KitEditorMenu implements InventoryHolder {

    private final Map<Integer, String> slotMode = new HashMap<>();
    private Inventory inventory;

    public Map<Integer, String> slotMode() { return slotMode; }

    @Override
    public Inventory getInventory() { return inventory; }

    public static void open(SparkDuels plugin, Player player) {
        KitEditorMenu menu = new KitEditorMenu();
        List<Mode> modes = new ArrayList<>(plugin.modes().all());

        int size = Gui.sizeFor(modes.size());
        Inventory inv = Bukkit.createInventory(menu, size,
                plugin.msg().parse("<gradient:#3CFF7E:#11A65B><bold>\u270E ᴇᴅɪᴛ ʏᴏᴜʀ ᴋɪᴛs</bold></gradient>"));
        menu.inventory = inv;

        Gui.border(inv, Gui.pane(Material.GRAY_STAINED_GLASS_PANE));
        Gui.corners(inv, Gui.pane(Material.LIME_STAINED_GLASS_PANE));

        int[] slots = Gui.centered(modes.size(), size);
        for (int i = 0; i < modes.size() && i < slots.length; i++) {
            Mode m = modes.get(i);
            ItemStack icon = new ItemStack(m.icon());
            ItemMeta meta = icon.getItemMeta();
            meta.displayName(plugin.msg().item(m.display()));
            boolean custom = plugin.playerKits().has(player.getUniqueId(), m.id());
            meta.lore(List.of(
                    plugin.msg().item("<gray>ᴋɪᴛ: <white>" + m.kit()),
                    plugin.msg().item(custom ? "<#3CFF7E>\u2714 ᴄᴜsᴛᴏᴍ ʟᴏᴀᴅᴏᴜᴛ sᴀᴠᴇᴅ" : "<dark_gray>ᴅᴇꜰᴀᴜʟᴛ ʟᴏᴀᴅᴏᴜᴛ"),
                    plugin.msg().item(""),
                    plugin.msg().item("<#FFD23C>\u25B6 ᴄʟɪᴄᴋ ᴛᴏ ᴇᴅɪᴛ")));
            icon.setItemMeta(meta);
            inv.setItem(slots[i], icon);
            menu.slotMode.put(slots[i], m.id());
        }
        Gui.fillEmpty(inv, Gui.pane(Material.BLACK_STAINED_GLASS_PANE));
        player.openInventory(inv);
        plugin.sounds().play(player, "gui-open");
    }
}
