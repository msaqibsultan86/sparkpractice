package studio.spark.duels.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Ctx;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Lightweight, flag-FIRST detection assist. Alerts staff by default.
 * Auto-punishment is opt-in (config punish-command) and OFF unless configured.
 * This is NOT a replacement for a dedicated anti-cheat (Grim/Vulcan).
 */
public class CheatWatch {

    private final SparkDuels plugin;
    private final Map<UUID, Integer> violations = new HashMap<>();
    private final Map<UUID, Long> lastFlag = new HashMap<>();

    public CheatWatch(SparkDuels plugin) { this.plugin = plugin; }

    public boolean enabled() { return plugin.getConfig().getBoolean("anticheat.enabled", true); }
    public boolean check(String name) { return enabled() && plugin.getConfig().getBoolean("anticheat." + name + ".enabled", true); }

    public double d(String path, double def) { return plugin.getConfig().getDouble("anticheat." + path, def); }
    public int i(String path, int def) { return plugin.getConfig().getInt("anticheat." + path, def); }

    /** Record a detection. Alerts staff; auto-punishes only if a punish-command is configured. */
    public void flag(Player p, String check, String detail) {
        if (!enabled()) return;
        // simple decay: reset counter if last flag was long ago
        long now = System.currentTimeMillis();
        Long last = lastFlag.get(p.getUniqueId());
        if (last != null && now - last > 60_000) violations.remove(p.getUniqueId());
        lastFlag.put(p.getUniqueId(), now);

        int vl = violations.merge(p.getUniqueId(), 1, Integer::sum);

        String perm = plugin.getConfig().getString("anticheat.alert-permission", "sparkpractice.staff");
        Ctx ctx = Ctx.of().put("player", p.getName()).put("check", check).put("detail", detail).put("count", vl);
        for (Player staff : Bukkit.getOnlinePlayers())
            if (staff.hasPermission(perm)) plugin.msg().send(staff, "anticheat.alert", ctx);
        plugin.getLogger().info("[Watch] " + p.getName() + " flagged " + check + " (" + detail + ") vl=" + vl);

        String cmd = plugin.getConfig().getString("anticheat.punish-command", "");
        int threshold = i("violations-before-punish", 8);
        if (cmd != null && !cmd.isEmpty() && vl >= threshold) {
            violations.remove(p.getUniqueId());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
        }
    }

    public void clear(Player p) { violations.remove(p.getUniqueId()); lastFlag.remove(p.getUniqueId()); }
}
