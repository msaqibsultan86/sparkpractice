package studio.spark.duels.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import studio.spark.duels.SparkDuels;

public class KitEditorListener implements Listener {

    private final SparkDuels plugin;

    public KitEditorListener(SparkDuels plugin) { this.plugin = plugin; }

    @EventHandler
    public void onClickNpc(PlayerInteractEntityEvent e) {
        if (!plugin.playerKitEditor().isNpc(e.getRightClicked())) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (plugin.playerKitEditor().isEditing(p)) plugin.playerKitEditor().save(p);
        else plugin.playerKitEditor().openMenu(p);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (plugin.playerKitEditor().isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (plugin.playerKitEditor().isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (plugin.playerKitEditor().isEditing(e.getPlayer())) e.setCancelled(true);
    }
}
