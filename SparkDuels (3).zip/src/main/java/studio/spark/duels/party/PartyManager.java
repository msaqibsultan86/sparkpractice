package studio.spark.duels.party;

import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Ctx;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PartyManager {

    private final SparkDuels plugin;
    private final Map<UUID, Party> byPlayer = new HashMap<>();

    public PartyManager(SparkDuels plugin) { this.plugin = plugin; }

    public Party getParty(Player p) { return byPlayer.get(p.getUniqueId()); }
    public boolean inParty(Player p) { return byPlayer.containsKey(p.getUniqueId()); }

    public Party create(Player leader) {
        if (inParty(leader)) return getParty(leader);
        Party party = new Party(leader.getUniqueId());
        byPlayer.put(leader.getUniqueId(), party);
        plugin.msg().send(leader, "party.created");
        if (plugin.lobbyItems() != null) plugin.lobbyItems().give(leader);
        return party;
    }

    public void invite(Player leader, Player target) {
        Party party = getParty(leader);
        if (party == null) party = create(leader);
        if (!party.isLeader(leader.getUniqueId())) { plugin.msg().send(leader, "party.not-leader"); return; }
        if (party.size() >= plugin.getConfig().getInt("party.max-size", 8)) { plugin.msg().send(leader, "party.full"); return; }
        party.invites().add(target.getUniqueId());
        plugin.msg().send(leader, "party.invited", Ctx.of().target(target));
        plugin.msg().sendRaw(target, plugin.msg().raw("party.invite-received"), Ctx.of().put("player", leader.getName()));
        plugin.sounds().play(target, "party-invite");
    }

    public void accept(Player target, Player leader) {
        Party party = getParty(leader);
        if (party == null || !party.invites().contains(target.getUniqueId())) { plugin.msg().send(target, "party.not-in-party"); return; }
        if (inParty(target)) { plugin.msg().send(target, "party.not-in-party"); return; }
        party.invites().remove(target.getUniqueId());
        party.members().add(target.getUniqueId());
        byPlayer.put(target.getUniqueId(), party);
        broadcast(party, "party.joined", Ctx.of().target(target));
        if (plugin.lobbyItems() != null) plugin.lobbyItems().give(target);
    }

    public void deny(Player target, Player leader) {
        Party party = getParty(leader);
        if (party != null) party.invites().remove(target.getUniqueId());
    }

    public void leave(Player p) {
        Party party = getParty(p);
        if (party == null) { plugin.msg().send(p, "party.not-in-party"); return; }
        party.members().remove(p.getUniqueId());
        byPlayer.remove(p.getUniqueId());
        plugin.msg().send(p, "party.left");
        if (plugin.lobbyItems() != null) plugin.lobbyItems().give(p);
        if (party.isLeader(p.getUniqueId()) && !party.members().isEmpty()) {
            party.leader(party.members().iterator().next());
        }
    }

    public void disband(Player p) {
        Party party = getParty(p);
        if (party == null) { plugin.msg().send(p, "party.not-in-party"); return; }
        if (!party.isLeader(p.getUniqueId())) { plugin.msg().send(p, "party.not-leader"); return; }
        broadcast(party, "party.disbanded", Ctx.of());
        for (UUID id : party.members()) byPlayer.remove(id);
        if (plugin.lobbyItems() != null) for (UUID id : party.members()) {
            Player mp = plugin.getServer().getPlayer(id);
            if (mp != null) plugin.lobbyItems().give(mp);
        }
    }

    public void kick(Player leader, Player target) {
        Party party = getParty(leader);
        if (party == null || !party.isLeader(leader.getUniqueId())) { plugin.msg().send(leader, "party.not-leader"); return; }
        if (!party.isMember(target.getUniqueId())) { plugin.msg().send(leader, "party.not-in-party"); return; }
        party.members().remove(target.getUniqueId());
        byPlayer.remove(target.getUniqueId());
        plugin.msg().send(target, "party.kicked");
    }

    public void chat(Player p, String message) {
        Party party = getParty(p);
        if (party == null) { plugin.msg().send(p, "party.not-in-party"); return; }
        for (UUID id : party.members()) {
            Player m = plugin.getServer().getPlayer(id);
            if (m != null) plugin.msg().sendRaw(m, plugin.msg().raw("party.chat-format"),
                    Ctx.of().put("player", p.getName()).put("message", message));
        }
    }

    public void list(Player p) {
        Party party = getParty(p);
        if (party == null) { plugin.msg().send(p, "party.not-in-party"); return; }
        StringBuilder sb = new StringBuilder();
        for (UUID id : party.members()) {
            Player m = plugin.getServer().getPlayer(id);
            if (sb.length() > 0) sb.append("<gray>, ");
            sb.append(party.isLeader(id) ? "<#3CFF7E>\u2605" : "<white>")
              .append(m != null ? m.getName() : "?");
        }
        plugin.msg().sendRaw(p, plugin.msg().prefix() + "<gray>ᴘᴀʀᴛʏ: " + sb, Ctx.of());
    }

    private void broadcast(Party party, String path, Ctx ctx) {
        for (UUID id : party.members()) {
            Player m = plugin.getServer().getPlayer(id);
            if (m != null) plugin.msg().send(m, path, ctx);
        }
    }

    /** Pair party members into 1v1 duels of the given mode. */
    public void startDuel(Player leader, String modeId) {
        Party party = getParty(leader);
        if (party == null || !party.isLeader(leader.getUniqueId())) { plugin.msg().send(leader, "party.not-leader"); return; }
        studio.spark.duels.model.Mode mode = plugin.modes().get(modeId);
        if (mode == null || !mode.duel()) { plugin.msg().send(leader, "queue.invalid-mode", Ctx.of().put("duel_mode", modeId)); return; }
        java.util.List<UUID> members = new java.util.ArrayList<>(party.members());
        if (members.size() < 2) { plugin.msg().send(leader, "party.too-small"); return; }
        int paired = 0;
        for (int i = 0; i + 1 < members.size(); i += 2) {
            Player a = plugin.getServer().getPlayer(members.get(i));
            Player b = plugin.getServer().getPlayer(members.get(i + 1));
            if (a != null && b != null) { plugin.matches().start(a, b, mode); paired++; }
        }
        broadcast(party, "party.duel-started", Ctx.of().put("duel_mode", mode.display()).put("count", paired));
    }

    /** Send all party members into the FFA arena for the given mode. */
    public void startFfa(Player leader, String modeId) {
        Party party = getParty(leader);
        if (party == null || !party.isLeader(leader.getUniqueId())) { plugin.msg().send(leader, "party.not-leader"); return; }
        studio.spark.duels.model.Mode mode = plugin.modes().get(modeId);
        if (mode == null || !mode.ffa()) { plugin.msg().send(leader, "ffa.invalid-mode", Ctx.of().put("ffa_mode", modeId)); return; }
        for (UUID id : party.members()) {
            Player m = plugin.getServer().getPlayer(id);
            if (m != null) plugin.ffa().join(m, modeId);
        }
        broadcast(party, "party.ffa-started", Ctx.of().put("ffa_mode", mode.display()));
    }

    // ---- party vs party (2v2) challenge ----
    public record TeamChallenge(UUID fromLeader, String modeId, long expiresAt) {}
    private final java.util.Map<UUID, TeamChallenge> teamChallenges = new java.util.HashMap<>(); // toLeader -> challenge

    public void challenge(Player from, Player target, String modeId) {
        Party a = getParty(from);
        if (a == null || !a.isLeader(from.getUniqueId())) { plugin.msg().send(from, "party.not-leader"); return; }
        Party b = getParty(target);
        if (b == null) { plugin.msg().send(from, "party.target-no-party", Ctx.of().target(target)); return; }
        if (b == a) { plugin.msg().send(from, "party.self-challenge"); return; }
        if (a.members().size() != 2 || b.members().size() != 2) { plugin.msg().send(from, "party.need-two"); return; }
        studio.spark.duels.model.Mode mode = plugin.modes().get(modeId);
        if (mode == null || !mode.duel()) { plugin.msg().send(from, "queue.invalid-mode", Ctx.of().put("duel_mode", modeId)); return; }

        UUID toLeader = b.leader();
        long expiry = plugin.getConfig().getInt("duel.request-expiry", 30) * 1000L;
        teamChallenges.put(toLeader, new TeamChallenge(from.getUniqueId(), mode.id(), System.currentTimeMillis() + expiry));

        plugin.msg().send(from, "party.challenge-sent", Ctx.of().target(target).put("duel_mode", mode.display()));
        Player toLeaderP = plugin.getServer().getPlayer(toLeader);
        if (toLeaderP != null) {
            Ctx ctx = Ctx.of().put("player", from.getName()).put("duel_mode", mode.display());
            plugin.msg().sendRaw(toLeaderP, plugin.msg().raw("party.challenge-header"), ctx);
            plugin.msg().sendRaw(toLeaderP, plugin.msg().raw("party.challenge-buttons"), ctx);
            plugin.sounds().play(toLeaderP, "duel-request");
        }
    }

    public void acceptChallenge(Player leaderB) {
        TeamChallenge ch = teamChallenges.remove(leaderB.getUniqueId());
        if (ch == null) { plugin.msg().send(leaderB, "party.no-challenge"); return; }
        if (System.currentTimeMillis() > ch.expiresAt()) { plugin.msg().send(leaderB, "party.challenge-expired"); return; }
        Party b = getParty(leaderB);
        Player fromLeader = plugin.getServer().getPlayer(ch.fromLeader());
        Party a = fromLeader != null ? getParty(fromLeader) : null;
        if (a == null || b == null || !b.isLeader(leaderB.getUniqueId())) { plugin.msg().send(leaderB, "party.no-challenge"); return; }
        if (a.members().size() != 2 || b.members().size() != 2) { plugin.msg().send(leaderB, "party.need-two"); return; }
        studio.spark.duels.model.Mode mode = plugin.modes().get(ch.modeId());
        if (mode == null) { plugin.msg().send(leaderB, "queue.invalid-mode", Ctx.of().put("duel_mode", ch.modeId())); return; }

        plugin.teamMatches().start(new java.util.ArrayList<>(a.members()), new java.util.ArrayList<>(b.members()), mode, false);
    }

    public void denyChallenge(Player leaderB) {
        TeamChallenge ch = teamChallenges.remove(leaderB.getUniqueId());
        if (ch == null) { plugin.msg().send(leaderB, "party.no-challenge"); return; }
        Player fromLeader = plugin.getServer().getPlayer(ch.fromLeader());
        if (fromLeader != null) plugin.msg().send(fromLeader, "party.challenge-denied", Ctx.of().put("player", leaderB.getName()));
    }
}
