package studio.spark.duels.kit;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Slime;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.gui.KitEditorMenu;
import studio.spark.duels.model.Mode;
import studio.spark.duels.util.Ctx;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Per-player kit editor: TP to area, pick a mode, edit, click the green NPC to save. */
public class PlayerKitEditor {

    private final SparkDuels plugin;
    private final NamespacedKey npcKey;
    private final Map<UUID, String> editing = new HashMap<>();

    public PlayerKitEditor(SparkDuels plugin) {
        this.plugin = plugin;
        this.npcKey = new NamespacedKey(plugin, "kiteditor_npc");
    }

    public boolean isEditing(Player p) { return editing.containsKey(p.getUniqueId()); }
    public boolean areaConfigured() { return spawn() != null; }

    public Location spawn() { return readLoc("kit-editor.spawn"); }
    public Location npc() { Location n = readLoc("kit-editor.npc"); return n != null ? n : spawn(); }
    public Location corner1() { return readLoc("kit-editor.corner1"); }
    public Location corner2() { return readLoc("kit-editor.corner2"); }

    public void openMenu(Player p) {
        if (plugin.matches().isInMatch(p) || plugin.ffa().isInFfa(p) || plugin.queue().isQueued(p)) {
            plugin.msg().send(p, "duel.already-in-match");
            return;
        }
        if (!areaConfigured()) { plugin.msg().send(p, "kiteditor.not-setup"); return; }
        p.teleport(spawn());
        KitEditorMenu.open(plugin, p);
    }

    public void selectMode(Player p, String modeId) {
        Mode mode = plugin.modes().get(modeId);
        if (mode == null) { plugin.msg().send(p, "kit.not-found", Ctx.of().put("kit", modeId)); return; }
        editing.put(p.getUniqueId(), mode.id().toLowerCase(Locale.ROOT));
        p.getInventory().clear();
        if (!plugin.playerKits().applyTo(p, mode.id())) {
            Kit def = plugin.kits().get(mode.kit());
            if (def != null) def.apply(p);
        }
        p.setGameMode(GameMode.CREATIVE);
        plugin.msg().send(p, "kiteditor.editing", Ctx.of().put("mode", mode.display()));
        plugin.sounds().play(p, "gui-open");
    }

    public void save(Player p) {
        String modeId = editing.remove(p.getUniqueId());
        if (modeId == null) return;
        plugin.playerKits().store(p, modeId);
        plugin.msg().send(p, "kiteditor.saved");
        plugin.sounds().play(p, "success");
        plugin.lobby().toLobby(p);
    }

    public void cancel(Player p) {
        if (editing.remove(p.getUniqueId()) != null) p.getInventory().clear();
    }

    // ---- green NPC (save point) ----
    public boolean isNpc(Entity e) {
        return e != null && e.getPersistentDataContainer().has(npcKey, PersistentDataType.BYTE);
    }

    public void spawnNpc() {
        Location loc = npc();
        if (loc == null || loc.getWorld() == null) return;
        removeNpcs();
        loc.getChunk().load();
        Slime slime = loc.getWorld().spawn(loc, Slime.class);
        slime.setSize(2);
        slime.setAI(false);
        slime.setInvulnerable(true);
        slime.setSilent(true);
        slime.setGravity(false);
        slime.setCollidable(false);
        slime.setRemoveWhenFarAway(false);
        slime.setPersistent(true);
        slime.customName(plugin.msg().item("<gradient:#3CFF7E:#11A65B><bold>\u2714 ᴄʟɪᴄᴋ ᴛᴏ sᴀᴠᴇ ᴋɪᴛ</bold></gradient>"));
        slime.setCustomNameVisible(true);
        slime.getPersistentDataContainer().set(npcKey, PersistentDataType.BYTE, (byte) 1);
    }

    public void removeNpcs() {
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (e instanceof Slime && e.getPersistentDataContainer().has(npcKey, PersistentDataType.BYTE))
                    e.remove();
    }

    // ---- config location helpers ----
    private Location readLoc(String path) {
        var sec = plugin.getConfig().getConfigurationSection(path);
        if (sec == null) return null;
        World w = Bukkit.getWorld(sec.getString("world", ""));
        if (w == null) return null;
        return new Location(w, sec.getDouble("x"), sec.getDouble("y"), sec.getDouble("z"),
                (float) sec.getDouble("yaw"), (float) sec.getDouble("pitch"));
    }

    public void writeLoc(String path, Location l) {
        plugin.getConfig().set(path + ".world", l.getWorld().getName());
        plugin.getConfig().set(path + ".x", l.getX());
        plugin.getConfig().set(path + ".y", l.getY());
        plugin.getConfig().set(path + ".z", l.getZ());
        plugin.getConfig().set(path + ".yaw", (double) l.getYaw());
        plugin.getConfig().set(path + ".pitch", (double) l.getPitch());
        plugin.saveConfig();
    }
}
