package studio.spark.duels.kit;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import studio.spark.duels.SparkDuels;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Per-player custom kits (one loadout per mode), saved with native ItemStack serialization. */
public class PlayerKitManager {

    private final SparkDuels plugin;
    private final File file;
    private YamlConfiguration cfg;

    public PlayerKitManager(SparkDuels plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "playerkits.yml");
        load();
    }

    public void load() {
        cfg = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
    }

    public void save() {
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save playerkits.yml: " + e.getMessage());
        }
    }

    private String key(UUID id, String modeId) {
        return id + "." + modeId.toLowerCase(Locale.ROOT);
    }

    public boolean has(UUID id, String modeId) {
        return cfg.contains(key(id, modeId));
    }

    public void store(Player p, String modeId) {
        PlayerInventory inv = p.getInventory();
        String base = key(p.getUniqueId(), modeId);
        cfg.set(base, null);
        cfg.set(base + ".helmet", inv.getHelmet());
        cfg.set(base + ".chestplate", inv.getChestplate());
        cfg.set(base + ".leggings", inv.getLeggings());
        cfg.set(base + ".boots", inv.getBoots());
        cfg.set(base + ".offhand", inv.getItemInOffHand());
        cfg.set(base + ".contents", new ArrayList<>(Arrays.asList(inv.getStorageContents())));
        save();
    }

    /** Applies a player's custom kit for the mode. Returns true if one existed. */
    public boolean applyTo(Player p, String modeId) {
        String base = key(p.getUniqueId(), modeId);
        if (!cfg.contains(base)) return false;
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setHelmet(cfg.getItemStack(base + ".helmet"));
        inv.setChestplate(cfg.getItemStack(base + ".chestplate"));
        inv.setLeggings(cfg.getItemStack(base + ".leggings"));
        inv.setBoots(cfg.getItemStack(base + ".boots"));
        ItemStack off = cfg.getItemStack(base + ".offhand");
        if (off != null) inv.setItemInOffHand(off);
        List<?> list = cfg.getList(base + ".contents");
        if (list != null) {
            ItemStack[] contents = new ItemStack[36];
            for (int i = 0; i < list.size() && i < 36; i++) {
                if (list.get(i) instanceof ItemStack is) contents[i] = is;
            }
            inv.setStorageContents(contents);
        }
        return true;
    }

    public void delete(UUID id, String modeId) {
        cfg.set(key(id, modeId), null);
        save();
    }
}
